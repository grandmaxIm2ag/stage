# K Moyenne
Grand Maxence

    python kmeans.py k error filename
    
* k : nombre de clusters, cet argument doit être un entier.
* error : taux d'erreur accepté pour la k moyenne, cet argument doit être
  un flottant
* filename : fichier dans lequel est enregistré la visualisation du clustering
